﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using сандали.MyClass;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace сандали
{
    public partial class UserControlZakaz : UserControl
    {
        public string IdZak, NumZak, StatusZak, DataZakaza, AdresPunkt, DataDostavk, Stoimost;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void UserControlZakaz_Click(object sender, EventArgs e)
        {
            if (int.Parse(ConnectionBD.roll) == 1)
            {
                FormUppZakaz formUpp = new FormUppZakaz(IdZak);
                formUpp.ShowDialog();
                FormListZakaz parent = this.FindForm() as FormListZakaz;

                if (parent != null)
                {
                    parent.LoadTovars();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormListTovarInZakaz form = new FormListTovarInZakaz(IdZak);
            form.ShowDialog();

            FormListZakaz parent = this.FindForm() as FormListZakaz;

            if (parent != null)
            {
                parent.LoadTovars();
            }

        }

        public UserControlZakaz(string id, string NumZakaza, string Status,string adress, string DateZak, string DelivZak, string stoimostZak)
        {
            InitializeComponent();
            IdZak = id;
            NumZak = NumZakaza;
            StatusZak = Status;
            AdresPunkt = adress;
            DataZakaza = DateZak;
            DataDostavk = DelivZak;
            Stoimost = stoimostZak;

            if (int.Parse(ConnectionBD.roll) != 1)
            {
                button1.Visible = false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UserControlZakaz_Load(object sender, EventArgs e)
        {
            if (Stoimost == null)
            {
                label2.Text = $@"Номер заказа {NumZak} | Стоимость заказа: 0";
            }
            label1.Text = $@"Дата доставки {DataDostavk} ";
            label2.Text = $@"Номер заказа {NumZak} | Стоимость заказа: {Stoimost}";
            label3.Text = $@"Статус заказа: {StatusZak}";
            label4.Text = $@"Адрес пункта выдачи: {AdresPunkt}";
            label5.Text = $@"Дата заказа: {DataZakaza}";
        }
    }
}
